import { ConfigModule, ConfigService } from '@nestjs/config'
import { AllEntities } from 'src/entities'
import { DataSource } from 'typeorm'
const SC = process.env.NODE_ENV === 'dev' ? 'mysql.dev' : 'mysql.prd'
export const databaseProviders = [
  {
    provide: 'DATA_SOURCE',
    imports: [ConfigModule],
    inject: [ConfigService],
    useFactory: async (configService: ConfigService) => {
      const dataSource = new DataSource({
        type: 'mysql',
        host: configService.get(`${SC}.host`),
        port: configService.get(`${SC}.port`),
        username: configService.get(`${SC}.username`),
        password: configService.get(`${SC}.password`),
        database: configService.get(`${SC}.database`),
        synchronize: true,
        migrationsRun: true,
        entities: AllEntities,
        timezone: 'Z'
      })
      return dataSource.initialize()
    }
  }
]
