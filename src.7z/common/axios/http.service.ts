import { HttpService } from '@nestjs/axios'
import { HttpException, HttpStatus, Injectable } from '@nestjs/common'
import { catchError, firstValueFrom, map, Observable } from 'rxjs'
import { AxiosError, AxiosResponse } from 'axios'
import { genErrorMsg } from '../utils/util'
import { CODE } from '../enums/code.enum'
import { ConfigService } from '@nestjs/config'
@Injectable()
export class AxiosService {
  protected readonly TOKEN: string
  constructor(private readonly httpService: HttpService, private readonly configService: ConfigService) {
    this.TOKEN = this.configService.get<string>('http.token')
  }

  pipe(ob: Observable<AxiosResponse<any, any>>) {
    return ob.pipe(
      map((response) => {
        return response.data
      }),
      catchError((error: AxiosError) => {
        throw new HttpException(
          genErrorMsg(CODE.SENTRY_ERROR, error.response.data as { detail: string }['detail']),
          HttpStatus.OK
        )
      })
    )
  }
  async post<T>(sub_url: string, params: any) {
    return await firstValueFrom<T>(
      this.httpService
        .post(sub_url, params, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: this.TOKEN
          }
        })
        .pipe(
          map((response) => {
            return response.data
          }),
          catchError((error: AxiosError) => {
            throw new HttpException(
              genErrorMsg(CODE.SENTRY_ERROR, error.response.data as { detail: string }['detail']),
              HttpStatus.OK
            )
          })
        )
    )
  }

  async get<T>(sub_url: string, config?: any) {
    return await firstValueFrom<T>(
      this.httpService
        .get(sub_url, {
          headers: {
            Authorization: this.TOKEN
          },
          ...config
        })
        .pipe(
          map((response) => {
            return response.data
          }),
          catchError((error: AxiosError) => {
            throw new HttpException(
              genErrorMsg(CODE.SENTRY_ERROR, error.response.data as { detail: string }['detail']),
              HttpStatus.OK
            )
          })
        )
    )
  }
}
