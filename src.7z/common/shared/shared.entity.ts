import { BaseEntity, PrimaryGeneratedColumn, Index, Column } from 'typeorm'
export class SharedEntity extends BaseEntity {
  /** 主键id */
  @Index('id')
  @PrimaryGeneratedColumn()
  id: number

  /** 创建时间 */
  @Index('createdAt')
  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP', comment: '创建时间' })
  createdAt: Date

  /** 创建者名 */
  @Column({ comment: '创建者名', default: 'admin' })
  createName: string

  /** 更新者名 */
  @Column({ comment: '更新者名', default: 'admin' })
  updateName: string
}
