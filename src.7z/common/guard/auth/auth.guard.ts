import { CanActivate, ExecutionContext, HttpException, HttpStatus, Inject, Injectable } from '@nestjs/common'
import { Reflector } from '@nestjs/core'
import { ApiTypeEnum } from 'src/common/enums/api.enum'
import { CODE } from 'src/common/enums/code.enum'
import { PROVIDERS } from 'src/common/enums/sysyem.enum'
import { genErrorMsg, verifyToken } from 'src/common/utils/util'
import { UserEntity } from 'src/entities/user.entity'
import { DataSource } from 'typeorm'

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(@Inject(PROVIDERS.DB) private dataSource: DataSource, private readonly reflector: Reflector) {}
  async canActivate(context: ExecutionContext): Promise<boolean> {
    const apiType = this.reflector.get<ApiTypeEnum>('apiType', context.getHandler())
    if (apiType & ApiTypeEnum.EXCLUDE) {
      return true
    }
    // 暂定在请求头部添加token
    const request = context.switchToHttp().getRequest()
    const token = request.headers.authorization?.replace('Bearer ', '') || ''
    if (!token) {
      throw new HttpException(genErrorMsg(CODE.TOKEN_ERROR), HttpStatus.BAD_REQUEST)
    }
    /** 校验token是否合法 */
    /** 获取用户信息 */
    const id = verifyToken(token)
    const { body } = request
    if (id) {
      const user = await this.dataSource
        .createQueryBuilder(UserEntity, 'u')
        .select()
        .where('u.id = :id', { id })
        .getOne()
      if (!user) {
        throw new HttpException(genErrorMsg(CODE.TOKEN_ERROR), HttpStatus.BAD_REQUEST)
      }
      request.user = user
      if (apiType) {
        if (apiType & ApiTypeEnum.CREATE) {
          if (Array.isArray(body)) {
            body.forEach((item) => {
              item.updateName = item.createName = user.username
            })
          } else {
            body.updateName = body.createName = user.username
          }
        }
        if (apiType & ApiTypeEnum.UPDATE) {
          if (Array.isArray(body)) {
            body.forEach((item) => {
              item.updateName = user.username
            })
          } else {
            body.updateName = user.username
          }
        }
      }
    }
    return true
  }
}
