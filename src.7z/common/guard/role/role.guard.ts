import { CanActivate, ExecutionContext, HttpException, HttpStatus, Injectable } from '@nestjs/common'
import { Reflector } from '@nestjs/core'
import { CODE } from 'src/common/enums/code.enum'
import { Role } from 'src/common/enums/role.enum'
import { genErrorMsg } from 'src/common/utils/util'

@Injectable()
export class RoleGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}
  async canActivate(context: ExecutionContext): Promise<boolean> {
    const roles =
      this.reflector.get<number[]>('roles', context.getHandler()) ||
      this.reflector.get<number[]>('roles', context.getClass())
    if (!roles || roles.includes(Role.EXCLUDE)) {
      return true
    }
    /** 检验只有特定角色才能使用 */
    const request = context.switchToHttp().getRequest()
    const user = request.user
    if (!roles.includes(user.role)) {
      throw new HttpException(genErrorMsg(CODE.UN_JURISDICTION), HttpStatus.BAD_REQUEST)
    }
    return true
  }
}
