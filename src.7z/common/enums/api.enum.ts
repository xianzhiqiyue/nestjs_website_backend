export enum ApiTypeEnum {
  /** 会在body添加createId和updateId */
  CREATE = 1 << 1,
  /** 会在body上添加updateId */
  UPDATE = 1 << 2,
  /** 不对权限进行校验 */
  EXCLUDE = 1 << 8
}
