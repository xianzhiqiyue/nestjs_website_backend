/** 用户枚举 */
export enum Role {
  /** 管理员 */
  ADMIN = 1,
  /** 普通用户 */
  NORMAL = 2,
  /** 不做用户校验 */
  EXCLUDE = 3
}
