/** providers */
export enum PROVIDERS {
  DB = 'DATA_SOURCE'
}

export enum IS_DELETED {
  DELETED = 'T', //删除
  UN_DELETED = 'F' //未删除
}
