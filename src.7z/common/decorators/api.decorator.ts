import { SetMetadata } from '@nestjs/common'
import { ApiTypeEnum } from '../enums/api.enum'
import { Role } from '../enums/role.enum'

export const ApiType = (type: ApiTypeEnum) => {
  return SetMetadata('apiType', type)
}

export const Roles = (...roles: Role[]) => {
  return SetMetadata('roles', roles)
}
