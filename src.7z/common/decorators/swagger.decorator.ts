import { applyDecorators, Type } from '@nestjs/common'
import { ApiResponse, getSchemaPath } from '@nestjs/swagger'

export const ApiError = () => {
  return applyDecorators(
    ApiResponse({
      status: 200,
      schema: {
        allOf: [
          {
            properties: {
              code: {
                type: 'number',
                description: 'code'
              },
              message: {
                type: 'string',
                description: '错误信息'
              },
              errorMsg: {
                type: 'string',
                description: '错误内容'
              },
              params: {
                type: 'any',
                description: '提交的参数'
              },
              method: {
                type: 'string',
                description: '接口类型'
              },
              path: {
                type: 'string',
                description: '接口地址'
              },
              timestamp: {
                type: 'string',
                description: '时间'
              }
            }
          }
        ]
      },
      description: '接口请求错误'
    })
  )
}

export const ApiDataResponse = <TModel extends Type<any>>(model: TModel, isArray = false) => {
  const result = isArray
    ? {
        allOf: [
          {
            properties: {
              count: {
                type: 'number',
                description: '总条数'
              },
              pageSize: {
                type: 'number',
                description: '每页条数'
              },
              pageNum: {
                type: 'number',
                description: '当前页数'
              },
              list: {
                type: 'array',
                items: { $ref: getSchemaPath(model) },
                description: '列表数据'
              }
            }
          }
        ]
      }
    : {
        $ref: getSchemaPath(model)
      }
  return applyDecorators(
    ApiResponse({
      status: 200,
      description: '调用成功返回数据',
      schema: {
        required: ['code', 'result', 'message'],
        allOf: [
          {
            properties: {
              result,
              code: {
                type: 'number',
                description: 'code'
              },
              message: {
                type: 'string',
                description: '返回信息'
              }
            }
          }
        ]
      }
    }),
    ApiResponse({
      status: 200,
      schema: {
        allOf: [
          {
            properties: {
              code: {
                type: 'number',
                description: 'code'
              },
              message: {
                type: 'string',
                description: '错误信息'
              },
              params: {
                type: 'any',
                description: '提交的参数'
              },
              method: {
                type: 'string',
                description: '接口类型'
              },
              path: {
                type: 'string',
                description: '接口地址'
              },
              timestamp: {
                type: 'string',
                description: '时间'
              }
            }
          }
        ]
      },
      description: '接口请求错误'
    })
  )
}
