import { PipeTransform, Injectable } from '@nestjs/common'

@Injectable()
export class ParsePagePipe implements PipeTransform {
  transform(obj: any) {
    if (!obj.pageSize) {
      obj.pageSize = 10
    }
    if (!obj.pageNum) {
      obj.pageNum = 1
    }
    return obj
  }
}
