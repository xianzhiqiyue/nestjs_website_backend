import { Injectable, Scope } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import * as nodemailer from 'nodemailer'

/**
 * 邮件服务
 */
@Injectable({ scope: Scope.REQUEST })
export class MailClientService {
  protected readonly userMail: string
  transporter: nodemailer.Transporter
  constructor(private readonly configService: ConfigService) {
    const emailConfig = this.configService.get<{ userMail: string; mailServer: string; authPass: string }>(
      'email'
    )
    const { userMail, mailServer, authPass } = emailConfig
    this.userMail = userMail
    this.transporter = nodemailer.createTransport({
      host: mailServer, // 服务器
      secureConnection: true, // 启动SSL
      port: 465, // 端口就是465
      auth: {
        user: userMail, // 账号
        pass: authPass // 授权码,
      }
    } as nodemailer.TransportOptions)
  }

  /**
   * 发送邮件
   * @param {Mail<T = any>.Options} mailOptions 接收者邮箱
   * @param {string} [mailOptions.from] 发送者邮箱
   * @param {string} mailOptions.subject 标题
   * @param {string} mailOptions.html 文本
   * @param {Array<{filename:string,path:string}>} mailOptions.attachments 附件
   * @return {Promise<SMTPTransport.SentMessageInfo>}
   */
  async sendMail({ from = this.userMail, to, subject, html, attachments = null }) {
    return await this.transporter.sendMail({ from, to, subject, html, attachments })
  }
}
