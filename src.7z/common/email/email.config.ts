// import mjml2html from 'mjml'
// import { compile } from 'handlebars'
// import { readFileSync } from 'fs'
import { CreateFeedbackDto } from 'src/dto/feedback.dto'
import { QUESTION_DESC, QUESTION_TYPE } from '../enums/feedback.enum'
import Mail from 'nodemailer/lib/mailer'
import { ProductEntity } from 'src/entities/product.entity'
// import { join } from 'path'

// const TEMPLATE_PATH = process.env.NODE_ENV === 'dev' ? '../../email.template.mjml' : './email.template.mjml'

// 使用handlebars对mjml文件进行编译
// const template = compile(readFileSync(join(__dirname, TEMPLATE_PATH), 'utf8'))

function getHTML(feedback: CreateFeedbackDto) {
  const { version, type, content, contact, name } = feedback
  return `
    <table border="1" width="800" cellspacing="0" align="center" cellpadding="0">
      <tr>
        <th style="width:100px;">版本</th>
        <th style="width:150px;">类型</th>
        <th style="width:300px;">错误信息</th>
        <th style="width:150px;">联系人</th>
        <th style="width:100px;">联系方式</th>
      </tr>
      <tr>
        <td>${version}</td>
        <td>${type}</td>
        <td>${content}</td>
        <td>${name}</td>
        <td>${contact}</td>
      </tr>
    </table>
  `
}
export const getMailOption = function (feedback: CreateFeedbackDto): Mail.Options {
  const { product, type } = feedback
  const { productName } = product as ProductEntity
  const config = Object.assign({}, feedback, {
    product: productName,
    type: QUESTION_DESC[QUESTION_TYPE[type]]
  })
  // const temp = template(config)

  const html = getHTML(config)
  return {
    subject: `关于${productName}的反馈信息`, // 标题
    html
  }
}
