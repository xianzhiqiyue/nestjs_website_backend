import { NestFactory } from '@nestjs/core'
import { AppModule } from './app.module'
import { ConfigService } from '@nestjs/config'
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger'
import { TransformInterceptor } from './common/interceptor/transform.interceptor'
import { HttpExceptionFilter } from './common/filter/http-exception.filter'
import { NestExpressApplication } from '@nestjs/platform-express'
declare const module: any
async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule)
  const configService = app.get(ConfigService)
  const config = new DocumentBuilder()
    .setTitle('Software feedback')
    .setDescription('用户反馈系统接口文档')
    .setVersion('1.0')
    .build()
  const document = SwaggerModule.createDocument(app, config)
  SwaggerModule.setup('api-docs', app, document)
  app.useStaticAssets('public', {
    prefix: '/static'
  })
  app.useGlobalInterceptors(new TransformInterceptor())
  app.useGlobalFilters(new HttpExceptionFilter())
  app.setGlobalPrefix('api')
  app.enableCors()
  const port = configService.get('server.port')
  process.env.PORT = port
  await app.listen(port)
  if (module.hot) {
    module.hot.accept()
    module.hot.dispose(() => app.close())
  }
}
bootstrap()
