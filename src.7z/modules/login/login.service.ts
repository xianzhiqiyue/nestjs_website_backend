import { HttpException, HttpStatus, Inject, Injectable, Logger } from '@nestjs/common'
import { LoginDto } from 'src/dto/login.dto'
import { UserEntity } from 'src/entities/user.entity'
import { CODE } from 'src/common/enums/code.enum'
import { PROVIDERS } from 'src/common/enums/sysyem.enum'
import { DataSource } from 'typeorm'
import { comparePwd, genErrorMsg, genToken } from 'src/common/utils/util'
import * as _ from 'lodash'

@Injectable()
export class LoginService {
  constructor(@Inject(PROVIDERS.DB) private dataSource: DataSource) {}
  async loginIn(loginDto: LoginDto) {
    const { username, password } = loginDto
    const user = await this.dataSource
      .createQueryBuilder(UserEntity, 'u')
      .select()
      .addSelect(['u.password'])
      .where('BINARY u.username = :username', { username })
      .leftJoin('u.bussinessLine', 'bussinessLine')
      .addSelect(['bussinessLine.id'])
      .getOne()
    if (!user) {
      Logger.error('账号不存在')
      throw new HttpException(genErrorMsg(CODE.USER_NOT_EXITS), HttpStatus.OK)
    }
    if (!(await comparePwd(password, user.password))) {
      Logger.error('密码错误')
      throw new HttpException(genErrorMsg(CODE.USER_PASSWORD_ERR), HttpStatus.OK)
    }
    const loginUser = _.cloneDeep<UserEntity>(user)
    delete loginUser.password
    return {
      token: genToken(user.id),
      user: loginUser
    }
  }
}
