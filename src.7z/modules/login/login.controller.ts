import { Body, Controller, Post } from '@nestjs/common'
import { ApiTags } from '@nestjs/swagger'
import { LoginService } from './login.service'
import { LoginDto } from 'src/dto/login.dto'
import { ApiDataResponse } from 'src/common/decorators/swagger.decorator'
import { LoginVo } from 'src/dto/vo/user.vo'
@ApiTags('用户登录')
@Controller()
export class LoginController {
  constructor(private readonly loginService: LoginService) {}
  /** 用户登录 */
  @ApiDataResponse(LoginVo)
  @Post('loginIn')
  loginIn(@Body() loginDto: LoginDto) {
    return this.loginService.loginIn(loginDto)
  }
}
