import { HttpModule } from '@nestjs/axios'
import { Module } from '@nestjs/common'
import { ConfigModule, ConfigService } from '@nestjs/config'
import { AxiosService } from 'src/common/axios/http.service'
import { MailClientService } from 'src/common/email/email.service'
import { databaseProviders } from '../providers/database.providers'
import { BussinessLineController } from './bussinessLine/bussinessLine.controller'
import { BussinessLineService } from './bussinessLine/bussinessLine.service'
import { FeedbackController } from './feedback/feedback.controller'
import { FeedbackService } from './feedback/feedback.service'
import { LoginController } from './login/login.controller'
import { LoginService } from './login/login.service'
import { ProductController } from './product/product.controller'
import { ProductService } from './product/product.service'
import { UploadController } from './upload/upload.controller'
import { UploadService } from './upload/upload.service'
import { UserController } from './user/user.controller'
import { UserService } from './user/user.service'

@Module({
  imports: [
    HttpModule.registerAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        baseURL: `${configService.get('http.host')}:${configService.get('http.port')}`,
        timeout: 5000
      }),
      inject: [ConfigService]
    })
  ],
  controllers: [
    FeedbackController,
    UploadController,
    ProductController,
    LoginController,
    UserController,
    BussinessLineController
  ],
  providers: [
    ...databaseProviders,
    FeedbackService,
    UploadService,
    ProductService,
    LoginService,
    UserService,
    BussinessLineService,
    AxiosService,
    MailClientService
  ]
})
export class SystemModule {}
