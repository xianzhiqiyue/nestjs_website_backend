import { Body, Controller, Get, Post, Query, UseGuards } from '@nestjs/common'
import { ApiType, Roles } from 'src/common/decorators/api.decorator'
import { Role } from 'src/common/enums/role.enum'
import { ProductService } from './product.service'
import { ApiDataResponse } from 'src/common/decorators/swagger.decorator'
import { ApiTags } from '@nestjs/swagger'
import { ApiTypeEnum } from 'src/common/enums/api.enum'
import { ProductEntity } from 'src/entities/product.entity'
import { ParsePagePipe } from 'src/common/pipe/parsePage.pipe'
import { BaseIdDto } from 'src/dto/base.dto'
import { CreateProductDto, GetProductListDto, UpdateProductDto } from 'src/dto/product.dto'
import { AuthGuard } from 'src/common/guard/auth/auth.guard'
import { RoleGuard } from 'src/common/guard/role/role.guard'
import { AffectedVO } from 'src/dto/vo/user.vo'
import { IS_DELETED } from 'src/common/enums/sysyem.enum'

@ApiTags('产品管理')
@Controller('product')
@UseGuards(AuthGuard, RoleGuard)
@Roles(Role.ADMIN, Role.NORMAL)
export class ProductController {
  constructor(private productService: ProductService) {}

  /** 创建产品 */
  @ApiDataResponse(CreateProductDto)
  @ApiType(ApiTypeEnum.CREATE)
  @Post('createProduct')
  createFeedback(@Body() createProductDto: CreateProductDto) {
    return this.productService.createProduct(createProductDto)
  }

  /** 获取产品列表  */
  @ApiDataResponse(ProductEntity, true)
  @Get('getProductList')
  getFeedbackList(@Query(new ParsePagePipe()) getProductListDto: GetProductListDto) {
    return this.productService.getProductList(getProductListDto)
  }

  /** 删除产品信息 */
  @ApiDataResponse(AffectedVO)
  @Post('deleteProduct')
  deleteFeedback(@Body() baseIdDto: BaseIdDto) {
    return this.productService.deleteProduct(baseIdDto, IS_DELETED.DELETED)
  }

  /** 更新产品信息 */
  @ApiDataResponse(AffectedVO)
  @ApiType(ApiTypeEnum.UPDATE)
  @Post('updateProduct')
  updateProduct(@Body() updateProductDto: UpdateProductDto) {
    return this.productService.updateProduct(updateProductDto)
  }

  /** 获取产品信息  */
  @ApiDataResponse(ProductEntity)
  @Get('getProduct')
  getFeedback(@Query() baseIdDto: BaseIdDto) {
    return this.productService.getProduct(baseIdDto)
  }
}
