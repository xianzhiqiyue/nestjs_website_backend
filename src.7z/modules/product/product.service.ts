import { Inject, Injectable, Scope } from '@nestjs/common'
import { IS_DELETED, PROVIDERS } from 'src/common/enums/sysyem.enum'
import { BaseIdDto } from 'src/dto/base.dto'
import { CreateProductDto, GetProductListDto, UpdateProductDto } from 'src/dto/product.dto'
import { BussinesslineEntity } from 'src/entities/bussinessLine.entity'
import { ProductEntity } from 'src/entities/product.entity'
import { DataSource, EntityManager } from 'typeorm'
import { BussinessLineService } from '../bussinessLine/bussinessLine.service'
import { AxiosService } from 'src/common/axios/http.service'
import { UserService } from '../user/user.service'
import { UserEntity } from 'src/entities/user.entity'
import { CommonService } from '../common/common.service'

@Injectable({ scope: Scope.REQUEST })
export class ProductService extends CommonService {
  readonly PRUDUCT_SUBURL = '/api/0/teams/ciqtek'
  readonly DSN_SBURL = 'api/0/projects/ciqtek'
  constructor(
    @Inject(PROVIDERS.DB) private dataSource: DataSource,
    @Inject(BussinessLineService) private bussinessLineService: BussinessLineService,
    @Inject(UserService) private userService: UserService,
    private readonly axiosService: AxiosService
  ) {
    super()
  }

  async createProduct(createProductDto: CreateProductDto) {
    const { productName, bussinessLineId, slugName, userIds } = createProductDto

    return this.dataSource.transaction(async (manager: EntityManager) => {
      const bussinessLine = await this.bussinessLineService.checkValueIsExist<BussinesslineEntity>(
        manager,
        BussinesslineEntity,
        {
          where: { id: bussinessLineId }
        }
      )

      const deletedProduct = await manager.findOne(ProductEntity, {
        where: {
          productName,
          isDeleted: IS_DELETED.DELETED
        }
      })

      const pruductEntityInstance = new ProductEntity()
      pruductEntityInstance.bussinessLine = bussinessLine

      if (!deletedProduct) {
        await this.checkValueHasSame<ProductEntity>(manager, ProductEntity, { productName })
      } else {
        pruductEntityInstance.isDeleted = IS_DELETED.UN_DELETED
        pruductEntityInstance.id = deletedProduct.id
      }

      const sentryProdct = await this.axiosService.post<{ slug: string; id: number }>(
        `${this.PRUDUCT_SUBURL}/${bussinessLine.sentryId}/projects/`,
        {
          name: productName,
          slug: slugName
        }
      )

      if (sentryProdct) {
        pruductEntityInstance.slugName = sentryProdct.slug

        const dsnData = await this.getProductDSN(slugName)
        if (dsnData && dsnData.length) {
          pruductEntityInstance.dsnUrl = (dsnData[0] as any)?.dsn?.public || ''
        }
      }

      if (userIds && userIds.length) {
        pruductEntityInstance.users = []
        await Promise.all(
          userIds.map(async (userId: number) => {
            const user = await this.userService.checkValueIsExist<UserEntity>(manager, UserEntity, {
              where: { id: userId }
            })
            const hasUser = pruductEntityInstance.users.find((u: UserEntity) => u.id === user.id)
            if (!hasUser) {
              pruductEntityInstance.users.push(user)
            }
          })
        )
      }

      const pr = manager.merge(ProductEntity, pruductEntityInstance, createProductDto)
      return manager.save(pr)
    })
  }

  async getProductList(GetProductListDto: GetProductListDto) {
    const { pageSize, pageNum, bussinessLineId } = GetProductListDto

    const manager = this.dataSource.createEntityManager()

    if (bussinessLineId) {
      await this.bussinessLineService.checkValueIsExist<BussinesslineEntity>(manager, BussinesslineEntity, {
        where: { id: bussinessLineId }
      })
    }

    const QR = this.dataSource
      .createQueryBuilder(ProductEntity, 'p')
      .leftJoinAndSelect('p.bussinessLine', 'bussinessLine')
      .leftJoinAndSelect('p.users', 'users')
      .where('p.isDeleted =:state', { state: IS_DELETED.UN_DELETED })

    if (bussinessLineId) {
      QR.where('p.bussinessLineId = :id', { id: bussinessLineId })
    }
    const [list, count] = await QR.skip((pageNum - 1) * pageSize)
      .take(pageSize)
      .getManyAndCount()
    return {
      pageSize,
      pageNum,
      count,
      list
    }
  }
  async deleteProduct(deleteProductDto: BaseIdDto, state: IS_DELETED) {
    const { id } = deleteProductDto
    return this.dataSource.transaction(async (manager) => {
      const product = await this.checkValueIsExist<ProductEntity>(manager, ProductEntity, { where: { id } })
      product.isDeleted = state
      await manager.save(product)
    })
  }

  updateProduct(updateProductDto: UpdateProductDto) {
    const { id, bussinessLineId, userIds, ...params } = updateProductDto
    return this.dataSource.transaction(async (manager: EntityManager) => {
      const product = await this.checkValueIsExist<ProductEntity>(manager, ProductEntity, {
        where: { id },
        relations: ['users']
      })

      const bussinessLine = await this.bussinessLineService.checkValueIsExist<BussinesslineEntity>(
        manager,
        BussinesslineEntity,
        {
          where: { id: bussinessLineId }
        }
      )
      params.bussinessLine = bussinessLine

      if (userIds && userIds.length) {
        params.users = []
        await Promise.all(
          userIds.map(async (userId: number) => {
            const user = await this.userService.checkValueIsExist<UserEntity>(manager, UserEntity, {
              where: { id: userId }
            })
            const hasUser = params.users.find((u: UserEntity) => u.id === user.id)
            if (!hasUser) {
              params.users.push(user)
            }
          })
        )
      }
      Object.assign(product, params)
      await manager.save(product)
    })
  }

  async getProduct(baseIdDto: BaseIdDto) {
    const { id } = baseIdDto
    return this.dataSource.transaction(async (manager: EntityManager) => {
      return await this.checkValueIsExist<ProductEntity>(manager, ProductEntity, {
        where: { id },
        relations: ['bussinessLine', 'users']
      })
    })
  }

  async getProductDSN(slug: string) {
    return await this.axiosService.get<any[]>(`${this.DSN_SBURL}/${slug}/keys/`, {
      baseURL: 'http://sentry.ciqtek.net'
    })
  }
}
