import {
  Body,
  Controller,
  Get,
  UseInterceptors,
  Post,
  UseGuards,
  UploadedFiles,
  Query,
  HttpException,
  HttpStatus
} from '@nestjs/common'
import { ApiType, Roles } from 'src/common/decorators/api.decorator'
import { Role } from 'src/common/enums/role.enum'
import { FilesInterceptor } from '@nestjs/platform-express'
import { AuthGuard } from 'src/common/guard/auth/auth.guard'
import { RoleGuard } from 'src/common/guard/role/role.guard'
import { FeedbackService } from './feedback.service'
import { ApiDataResponse } from 'src/common/decorators/swagger.decorator'
import {
  CreateFeedbackDto,
  GetFeedbackListDto,
  UpdateFeedbackDto,
  UpdateFeedbackStatusDto
} from 'src/dto/feedback.dto'
import { ApiTags } from '@nestjs/swagger'
import { ApiTypeEnum } from 'src/common/enums/api.enum'
import { FeedbackEntity } from 'src/entities/feedback.entity'
import { ParsePagePipe } from 'src/common/pipe/parsePage.pipe'
import { BaseIdDto } from 'src/dto/base.dto'
import { genErrorMsg } from 'src/common/utils/util'
import { CODE } from 'src/common/enums/code.enum'
import { AffectedVO } from 'src/dto/vo/user.vo'

@ApiTags('信息反馈')
@Controller('feedback')
export class FeedbackController {
  constructor(private feedbackService: FeedbackService) {}

  /** 创建反馈信息 */
  @ApiDataResponse(CreateFeedbackDto)
  @ApiType(ApiTypeEnum.CREATE)
  @UseInterceptors(
    FilesInterceptor('files', 5, {
      fileFilter(req, file, cb) {
        if (file.mimetype.split('/')[0] !== 'image') {
          return cb(new HttpException(genErrorMsg(CODE.FILE_NOT_LIMIT), HttpStatus.OK), false)
        }
        return cb(null, true)
      }
    })
  )
  @Roles(Role.EXCLUDE)
  @Post('createFeedback')
  createFeedback(
    @Body() createFeedbackDto: CreateFeedbackDto,
    @UploadedFiles()
    files: Array<Express.Multer.File>
  ) {
    return this.feedbackService.createFeedback(createFeedbackDto, files)
  }

  /** 获取反馈列表  */
  @UseGuards(AuthGuard, RoleGuard)
  @ApiDataResponse(FeedbackEntity, true)
  @Get('getFeedbackList')
  @Roles(Role.ADMIN, Role.NORMAL)
  getFeedbackList(@Query(new ParsePagePipe()) getFeedbackListDto: GetFeedbackListDto) {
    return this.feedbackService.getFeedbackList(getFeedbackListDto)
  }

  /** 删除反馈信息 */
  @UseGuards(AuthGuard, RoleGuard)
  @ApiDataResponse(AffectedVO)
  @Post('deleteFeedback')
  @Roles(Role.ADMIN)
  deleteFeedback(@Body() baseIdDto: BaseIdDto) {
    return this.feedbackService.deleteFeedback(baseIdDto)
  }

  /** 更新反馈信息 */
  @UseGuards(AuthGuard, RoleGuard)
  @ApiDataResponse(AffectedVO)
  @ApiType(ApiTypeEnum.UPDATE)
  @Post('updateFeedback')
  @Roles(Role.ADMIN)
  updateProduct(@Body() updateFeedbackDto: UpdateFeedbackDto) {
    return this.feedbackService.updateFeedback(updateFeedbackDto)
  }

  /** 获取反馈信息  */
  @UseGuards(AuthGuard, RoleGuard)
  @ApiDataResponse(FeedbackEntity)
  @Get('getFeedback')
  @Roles(Role.ADMIN, Role.NORMAL)
  getFeedback(@Query() baseIdDto: BaseIdDto) {
    return this.feedbackService.getFeedback(baseIdDto)
  }

  /** 更新反馈状态  */
  @UseGuards(AuthGuard, RoleGuard)
  @ApiDataResponse(FeedbackEntity)
  @Post('updateFeedbackStatus')
  @Roles(Role.ADMIN, Role.NORMAL)
  updateFeedbackStatus(@Body() updateFeedbackStatusDto: UpdateFeedbackStatusDto) {
    return this.feedbackService.updateFeedbackStatus(updateFeedbackStatusDto)
  }
}
