import { HttpException, HttpStatus, Inject, Injectable, Scope } from '@nestjs/common'
import { REQUEST } from '@nestjs/core'
import * as _ from 'lodash'
import { getMailOption } from 'src/common/email/email.config'
import { MailClientService } from 'src/common/email/email.service'
import { CODE } from 'src/common/enums/code.enum'
import { Role } from 'src/common/enums/role.enum'
import { PROVIDERS } from 'src/common/enums/sysyem.enum'
import { genErrorMsg } from 'src/common/utils/util'
import { BaseIdDto } from 'src/dto/base.dto'
import {
  CreateFeedbackDto,
  GetFeedbackListDto,
  UpdateFeedbackDto,
  UpdateFeedbackStatusDto
} from 'src/dto/feedback.dto'
import { BussinesslineEntity } from 'src/entities/bussinessLine.entity'
import { FeedbackEntity } from 'src/entities/feedback.entity'
import { PictureEntity } from 'src/entities/picture.entity'
import { ProductEntity } from 'src/entities/product.entity'
import { UserEntity } from 'src/entities/user.entity'
import { DataSource, EntityManager } from 'typeorm'
import { BussinessLineService } from '../bussinessLine/bussinessLine.service'
import { CommonService } from '../common/common.service'
import { ProductService } from '../product/product.service'
import { UploadService } from '../upload/upload.service'
@Injectable({ scope: Scope.REQUEST })
export class FeedbackService extends CommonService {
  constructor(
    @Inject(PROVIDERS.DB) private dataSource: DataSource,
    @Inject(REQUEST) private readonly req: any,
    @Inject(ProductService) private productService: ProductService,
    @Inject(UploadService) private uploadService: UploadService,
    @Inject(BussinessLineService) private bussinessLineService: BussinessLineService,
    @Inject(MailClientService) private mailClientService: MailClientService
  ) {
    super()
  }

  async createFeedback(createFeedbackDto: CreateFeedbackDto, files: Array<Express.Multer.File>) {
    const { productId } = createFeedbackDto
    return this.dataSource.transaction(async (manager: EntityManager) => {
      const product = await this.productService.checkValueIsExist<ProductEntity>(manager, ProductEntity, {
        where: { slugName: productId },
        relations: ['users', 'bussinessLine']
      })

      createFeedbackDto.product = product
      if (product.users && product.users.length) {
        const { subject, html } = await getMailOption(createFeedbackDto)
        Promise.all(
          product.users.map((user: UserEntity) => {
            this.mailClientService.sendMail({
              to: user.email,
              subject,
              html
            })
          })
        )
      }

      const bussinessLineId = product.bussinessLine.id
      const bussinessLine = await this.bussinessLineService.checkValueIsExist<BussinesslineEntity>(
        manager,
        BussinesslineEntity,
        { where: { id: bussinessLineId } }
      )
      createFeedbackDto.bussinessLine = bussinessLine

      if (files && files.length) {
        const picEntites = await this.uploadService.upload(files)
        createFeedbackDto.files = picEntites
      }

      const feedbackEntityInstance = new FeedbackEntity()

      const feedback = manager.merge(FeedbackEntity, feedbackEntityInstance, createFeedbackDto)

      return manager.save(feedback)
    })
  }

  async getFeedbackList(getFeedbackListDto: GetFeedbackListDto) {
    const {
      productId = '',
      bussinessLineId = '',
      startDate,
      endDate,
      status = '',
      content = '',
      pageSize,
      pageNum
    } = getFeedbackListDto

    if (!bussinessLineId) {
      const user = this.req.user
      if (user.role !== Role.ADMIN) {
        throw new HttpException(genErrorMsg(CODE.UN_JURISDICTION), HttpStatus.OK)
      }
    }
    const manager = this.dataSource.createEntityManager()
    if (productId) {
      await this.productService.checkValueIsExist<ProductEntity>(manager, ProductEntity, {
        where: { id: productId }
      })
    }
    if (bussinessLineId) {
      await this.bussinessLineService.checkValueIsExist<BussinesslineEntity>(manager, BussinesslineEntity, {
        where: { id: bussinessLineId }
      })
    }
    const QR = this.dataSource
      .createQueryBuilder(FeedbackEntity, 'f')
      .leftJoinAndSelect('f.product', 'product')
      .leftJoinAndSelect('f.bussinessLine', 'bussinessLine')
      .leftJoinAndSelect('f.files', 'files')

    if (status) {
      QR.andWhere('f.status = :status', { status })
    }
    if (bussinessLineId) {
      QR.andWhere('f.bussinessLineId = :bussinessLineId', { bussinessLineId })
    }
    if (productId) {
      QR.andWhere('f.productId = :productId', { productId })
    }
    if (content) {
      QR.andWhere('f.content LIKE :content', { content: `%${content}%` })
    }
    if (startDate && endDate) {
      QR.andWhere('f.createdAt BETWEEN :start AND :end', {
        start: `${startDate} 00:00:00`,
        end: `${endDate} 23:59:59`
      })
    }
    const [list, count] = await QR.skip((pageNum - 1) * pageSize)
      .take(pageSize)
      .orderBy('f.createdAt', 'DESC')
      .getManyAndCount()

    list.forEach((fb: FeedbackEntity) => {
      fb.files = fb.files?.map((f: PictureEntity) =>
        _.merge(f, {
          src: this.uploadService.getImageSrc(f.src)
        })
      )
    })
    return {
      pageSize,
      pageNum,
      count,
      list
    }
  }

  async getFeedback(deleteFeedbackDto: BaseIdDto) {
    const { id } = deleteFeedbackDto
    return this.dataSource.transaction(async (manager) => {
      await this.checkValueIsExist<FeedbackEntity>(manager, FeedbackEntity, { where: { id } })
      const feedback = await manager
        .createQueryBuilder(FeedbackEntity, 'f')
        .leftJoinAndSelect('f.product', 'product')
        .leftJoinAndSelect('f.files', 'files')
        .where('f.id = :id', { id })
        .getOne()
      feedback.files = feedback.files.map((f: PictureEntity) =>
        _.merge(f, {
          src: this.uploadService.getImageSrc(f.src)
        })
      )
      return feedback
    })
  }

  updateFeedback(updateFeedbackDto: UpdateFeedbackDto) {
    const { id, ...params } = updateFeedbackDto
    return this.dataSource.transaction(async (manager: EntityManager) => {
      await this.checkValueIsExist<FeedbackEntity>(manager, FeedbackEntity, { where: { id } })
      this.dataSource
        .createQueryBuilder()
        .update(FeedbackEntity)
        .set(params)
        .where('id= :id', { id })
        .execute()
    })
  }

  async deleteFeedback(getFeedbackDto: BaseIdDto) {
    const { id } = getFeedbackDto
    this.dataSource.transaction(async (manager: EntityManager) => {
      await this.checkValueIsExist<FeedbackEntity>(manager, FeedbackEntity, { where: { id } })
      manager.createQueryBuilder().delete().from(FeedbackEntity).where('id = :id', { id }).execute()
    })
  }

  updateFeedbackStatus(updateFeedbackStatusDto: UpdateFeedbackStatusDto) {
    const { id, status } = updateFeedbackStatusDto
    return this.dataSource.transaction(async (manager: EntityManager) => {
      const feedback = await this.checkValueIsExist<FeedbackEntity>(manager, FeedbackEntity, {
        where: { id }
      })
      if (feedback) {
        feedback.status = status
        await manager.save(feedback)
      }
    })
  }
}
