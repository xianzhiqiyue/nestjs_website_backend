import { Inject, Injectable, Scope } from '@nestjs/common'
import { IS_DELETED, PROVIDERS } from 'src/common/enums/sysyem.enum'
import { BaseIdDto } from 'src/dto/base.dto'
import {
  CreateBussinessLineDto,
  GetBussinessLineListDto,
  UpdateBussinessLineDto
} from 'src/dto/bussinessLine.dto'
import { BussinesslineEntity } from 'src/entities/bussinessLine.entity'
import { DataSource, EntityManager } from 'typeorm'
import { CommonService } from '../common/common.service'
import { AxiosService } from 'src/common/axios/http.service'

@Injectable({ scope: Scope.REQUEST })
export class BussinessLineService extends CommonService {
  readonly SENTRY_SUBURL = '/api/0/organizations/ciqtek/teams/'
  constructor(
    @Inject(PROVIDERS.DB) private dataSource: DataSource,
    private readonly axiosService: AxiosService
  ) {
    super()
  }

  async createBussinessLine(createBussinessLineDto: CreateBussinessLineDto) {
    return this.dataSource.transaction(async (manager: EntityManager) => {
      const { bussinessLineName } = createBussinessLineDto
      const deletedBussinessLine = await manager.findOne(BussinesslineEntity, {
        where: {
          bussinessLineName,
          isDeleted: IS_DELETED.DELETED
        }
      })

      if (!deletedBussinessLine) {
        await this.checkValueHasSame(manager, BussinesslineEntity, createBussinessLineDto)
      }

      const bussinessLineEntityInstance = new BussinesslineEntity()

      const sentryBussinessLine = await this.axiosService.post<{ slug: string }>(this.SENTRY_SUBURL, {
        name: bussinessLineName,
        slug: Math.random().toString(32).substring(2)
      })

      bussinessLineEntityInstance.sentryId = sentryBussinessLine.slug
      const bussinessLine = manager.merge(
        BussinesslineEntity,
        bussinessLineEntityInstance,
        createBussinessLineDto
      )

      if (deletedBussinessLine) {
        bussinessLineEntityInstance.id = deletedBussinessLine.id
        bussinessLineEntityInstance.isDeleted = IS_DELETED.UN_DELETED
      }
      return manager.save(bussinessLine)
    })
  }

  async getBussinessLineList(getBussinessLineList: GetBussinessLineListDto) {
    const { pageSize, pageNum } = getBussinessLineList
    const QR = this.dataSource
      .createQueryBuilder(BussinesslineEntity, 'u')
      .where('u.isDeleted =:state', { state: IS_DELETED.UN_DELETED })

    const [list, count] = await QR.skip((pageNum - 1) * pageSize)
      .take(pageSize)
      .getManyAndCount()
    return {
      pageSize,
      pageNum,
      count,
      list
    }
  }

  async deleteBussinessLine(deleteBussinessLineDto: BaseIdDto, state: IS_DELETED) {
    const { id } = deleteBussinessLineDto
    return this.dataSource.transaction(async (manager) => {
      const bussiness = await this.checkValueIsExist<BussinesslineEntity>(manager, BussinesslineEntity, {
        where: { id }
      })
      bussiness.isDeleted = state
      await manager.save(bussiness)
    })
  }

  updateBussinessLine(updateBussinessLineDto: UpdateBussinessLineDto) {
    const { id, ...params } = updateBussinessLineDto
    return this.dataSource.transaction(async (manager: EntityManager) => {
      const bussinessLine = await this.checkValueIsExist<BussinesslineEntity>(manager, BussinesslineEntity, {
        where: { id }
      })
      if (bussinessLine) {
        return this.dataSource
          .createQueryBuilder()
          .update(BussinesslineEntity)
          .set(params)
          .where('id= :id', { id })
          .execute()
      }
      manager.save(bussinessLine)
    })
  }

  async getBussinessLine(baseIdDto: BaseIdDto) {
    const { id } = baseIdDto
    return this.dataSource.transaction(async (manager: EntityManager) => {
      return await this.checkValueIsExist<BussinesslineEntity>(manager, BussinesslineEntity, {
        where: { id }
      })
    })
  }
}
