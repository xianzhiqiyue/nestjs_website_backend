import { Body, Controller, Get, Post, Query, UseGuards } from '@nestjs/common'
import { ApiType, Roles } from 'src/common/decorators/api.decorator'
import { Role } from 'src/common/enums/role.enum'
import { ApiDataResponse } from 'src/common/decorators/swagger.decorator'
import { ApiTags } from '@nestjs/swagger'
import { ApiTypeEnum } from 'src/common/enums/api.enum'
import { AuthGuard } from 'src/common/guard/auth/auth.guard'
import { RoleGuard } from 'src/common/guard/role/role.guard'
import {
  CreateBussinessLineDto,
  GetBussinessLineListDto,
  UpdateBussinessLineDto
} from 'src/dto/bussinessLine.dto'
import { BussinessLineService } from './bussinessLine.service'
import { BussinesslineEntity } from 'src/entities/bussinessLine.entity'
import { ParsePagePipe } from 'src/common/pipe/parsePage.pipe'
import { AffectedVO } from 'src/dto/vo/user.vo'
import { BaseIdDto } from 'src/dto/base.dto'
import { IS_DELETED } from 'src/common/enums/sysyem.enum'

@ApiTags('业务线管理')
@Controller('businessLine')
@UseGuards(AuthGuard, RoleGuard)
@Roles(Role.ADMIN, Role.NORMAL)
export class BussinessLineController {
  constructor(private bussinessLineService: BussinessLineService) { }

  /** 创建业务线 */
  @ApiDataResponse(CreateBussinessLineDto)
  @ApiType(ApiTypeEnum.CREATE)
  @Post('createBusinessLine')
  createBussinessLine(@Body() createBussinessLineDto: CreateBussinessLineDto) {
    return this.bussinessLineService.createBussinessLine(createBussinessLineDto)
  }

  /** 获取业务线列表  */
  @ApiDataResponse(BussinesslineEntity, true)
  @Get('getBusinessLineList')
  getBussinessLineList(@Query(new ParsePagePipe()) getbussinessLineListDto: GetBussinessLineListDto) {
    return this.bussinessLineService.getBussinessLineList(getbussinessLineListDto)
  }

  /** 删除业务线 */
  @ApiDataResponse(AffectedVO)
  @Post('deleteBusinessLine')
  deleteBussinessLine(@Body() baseIdDto: BaseIdDto) {
    return this.bussinessLineService.deleteBussinessLine(baseIdDto, IS_DELETED.DELETED)
  }

  /** 更新业务线 */
  @ApiDataResponse(AffectedVO)
  @ApiType(ApiTypeEnum.UPDATE)
  @Post('updateBusinessLine')
  updateBussinessLine(@Body() updateBussinessLineDto: UpdateBussinessLineDto) {
    return this.bussinessLineService.updateBussinessLine(updateBussinessLineDto)
  }

  /** 获取业务线信息  */
  @ApiDataResponse(BussinesslineEntity)
  @Get('getBusinessLine')
  getBussinessLine(@Query() baseIdDto: BaseIdDto) {
    return this.bussinessLineService.getBussinessLine(baseIdDto)
  }
}
