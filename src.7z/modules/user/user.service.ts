import { Inject, Injectable, Scope } from '@nestjs/common'
import { REQUEST } from '@nestjs/core'
import { IS_DELETED, PROVIDERS } from 'src/common/enums/sysyem.enum'
import { hashPwd } from 'src/common/utils/util'
import { BaseIdDto } from 'src/dto/base.dto'

import { CreateUserDto, GetUserListDto, UpdateUserDto } from 'src/dto/user.dto'
import { BussinesslineEntity } from 'src/entities/bussinessLine.entity'
import { UserEntity } from 'src/entities/user.entity'
import { DataSource, EntityManager } from 'typeorm'
import { BussinessLineService } from '../bussinessLine/bussinessLine.service'
import { CommonService } from '../common/common.service'

@Injectable({ scope: Scope.REQUEST })
export class UserService extends CommonService {
  constructor(
    @Inject(PROVIDERS.DB) private dataSource: DataSource,
    @Inject(BussinessLineService) private bussinessLineService: BussinessLineService,
    @Inject(REQUEST) private readonly req: any
  ) {
    super()
  }

  getUserInfo(baseIdDto: BaseIdDto) {
    const { id } = baseIdDto
    return this.dataSource.transaction(async (manager: EntityManager) => {
      return this.checkValueIsExist<UserEntity>(manager, UserEntity, {
        where: { id },
        relations: ['bussinessLine']
      })
    })
  }

  async getUserList(getUserListDto: GetUserListDto) {
    const { pageSize, pageNum, username = '' } = getUserListDto
    const QR = this.dataSource
      .createQueryBuilder(UserEntity, 'u')
      .leftJoinAndSelect('u.bussinessLine', 'bussinessLine')
      .where('u.username like :username', { username: `%${username}%` })
      .andWhere('u.isDeleted =:state', { state: IS_DELETED.UN_DELETED })

    const [list, count] = await QR.skip((pageNum - 1) * pageSize)
      .take(pageSize)
      .orderBy('u.createdAt', 'DESC')
      .getManyAndCount()
    return {
      pageSize,
      pageNum,
      count,
      list
    }
  }

  async createUser(createUserDto: CreateUserDto) {
    const { password, role, ...oths } = createUserDto
    const hash = await hashPwd(password)
    const manager = this.dataSource.createEntityManager()

    const deletedUser = await manager.findOne(UserEntity, {
      where: {
        username: createUserDto.username,
        isDeleted: IS_DELETED.DELETED
      }
    })

    if (!deletedUser) {
      await this.checkValueHasSame(manager, UserEntity, { username: oths.username })
    }

    const userInstance = new UserEntity()
    const { bussinessLineId } = oths
    if (bussinessLineId) {
      const bussinessLine = await this.bussinessLineService.checkValueIsExist<BussinesslineEntity>(
        manager,
        BussinesslineEntity,
        {
          where: { id: bussinessLineId }
        }
      )
      userInstance.bussinessLine = bussinessLine
    }

    const user = Object.assign(userInstance, oths, {
      password: hash,
      role
    })

    if (deletedUser) {
      user.id = deletedUser.id
      user.isDeleted = IS_DELETED.UN_DELETED
    }

    await manager.save(user)

    const { username, createName } = user
    return {
      role,
      username,
      createName
    }
  }

  async updateUser(updateUserDto: UpdateUserDto) {
    const { id, bussinessLineId, ...oths } = updateUserDto

    return this.dataSource.transaction(async (entityManager: EntityManager) => {
      const bussinessLine = await this.bussinessLineService.checkValueIsExist<BussinesslineEntity>(
        entityManager,
        BussinesslineEntity,
        {
          where: { id: bussinessLineId }
        }
      )
      const user = await this.checkValueIsExist<UserEntity>(entityManager, UserEntity, { where: { id } })

      oths.bussinessLine = bussinessLine
      if (oths.password) {
        oths.password = await hashPwd(oths.password)
      }
      if (user) {
        const updatedUser = entityManager.merge(UserEntity, user, oths)
        updatedUser.role = updateUserDto.role
        await entityManager.save(updatedUser)
        return updatedUser
      }
    })
  }

  async deleteUser(deleteUserDto: BaseIdDto, state: IS_DELETED) {
    const { id } = deleteUserDto
    return this.dataSource.transaction(async (manager) => {
      const user = await this.checkValueIsExist<UserEntity>(manager, UserEntity, { where: { id } })
      user.isDeleted = state
      manager.save(user)
    })
  }
}
