import { Body, Controller, Get, Post, Query, UseGuards } from '@nestjs/common'
import { ApiTags } from '@nestjs/swagger'
import { ApiType, Roles } from 'src/common/decorators/api.decorator'
import { ApiDataResponse } from 'src/common/decorators/swagger.decorator'
import { ApiTypeEnum } from 'src/common/enums/api.enum'
import { Role } from 'src/common/enums/role.enum'
import { AuthGuard } from 'src/common/guard/auth/auth.guard'
import { RoleGuard } from 'src/common/guard/role/role.guard'
import { CreateUserDto, GetUserListDto, UpdateUserDto } from 'src/dto/user.dto'
import { UserService } from './user.service'
import { AffectedVO, UserVo } from 'src/dto/vo/user.vo'
import { BaseIdDto } from 'src/dto/base.dto'
import { ParsePagePipe } from 'src/common/pipe/parsePage.pipe'
import { IS_DELETED } from 'src/common/enums/sysyem.enum'

@ApiTags('用户管理')
@UseGuards(AuthGuard, RoleGuard)
@Roles(Role.ADMIN)
@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  /** 获取用户详情 */
  @ApiDataResponse(UserVo)
  @Get('getUser')
  @Roles(Role.EXCLUDE)
  getUser(@Query() baseIdDto: BaseIdDto) {
    return this.userService.getUserInfo(baseIdDto)
  }

  /** 获取用户列表  */
  @ApiDataResponse(UserVo, true)
  @Get('getUserList')
  getUserList(@Body(new ParsePagePipe()) getUserListDto: GetUserListDto) {
    return this.userService.getUserList(getUserListDto)
  }

  /** 创建用户 */
  @ApiDataResponse(UserVo)
  @ApiType(ApiTypeEnum.CREATE)
  @Post('createUser')
  createUser(@Body() createUserDto: CreateUserDto) {
    return this.userService.createUser(createUserDto)
  }

  /** 删除用户 */
  @ApiDataResponse(AffectedVO)
  @ApiType(ApiTypeEnum.UPDATE)
  @Post('deleteUser')
  deleteUser(@Body() deleteUserDto: BaseIdDto) {
    return this.userService.deleteUser(deleteUserDto, IS_DELETED.DELETED)
  }

  /** 更新用户信息 */
  @ApiDataResponse(AffectedVO)
  @ApiType(ApiTypeEnum.UPDATE)
  @Post('updateUser')
  updateUser(@Body() updateUserDto: UpdateUserDto) {
    return this.userService.updateUser(updateUserDto)
  }
}
