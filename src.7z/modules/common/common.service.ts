import { HttpException, HttpStatus, Injectable, Scope } from '@nestjs/common'
import { CODE } from 'src/common/enums/code.enum'
import { IS_DELETED } from 'src/common/enums/sysyem.enum'
import { genErrorMsg } from 'src/common/utils/util'
import { EntityManager, EntityTarget, FindOneOptions, FindOptionsWhere } from 'typeorm'

@Injectable({ scope: Scope.REQUEST })
export class CommonService {
  /**
   * 查询值存在
   * @param manager
   * @param Entity 实体
   * @param option where配置
   * @returns 值
   */
  async checkValueIsExist<T>(manager: EntityManager, entity: EntityTarget<T>, option: FindOneOptions<T>) {
    if (option) {
      const value = await manager.findOne(entity, option)
      if (!value || value['isDeleted'] === IS_DELETED.DELETED) {
        throw new HttpException(genErrorMsg(CODE.VALUE_NOT_EXITS), HttpStatus.OK)
      }
      return value as T
    }
  }

  /**
   * 查询值重复
   * @param manager
   * @param Entity 实体
   * @param option where配置
   * @returns 值
   */
  async checkValueHasSame<T>(manager: EntityManager, Entity: EntityTarget<T>, option: FindOptionsWhere<T>) {
    if (option) {
      const value = await manager.findOne(Entity, { where: option })
      if (value) {
        throw new HttpException(genErrorMsg(CODE.SAME_VALUE), HttpStatus.OK)
      }
      return value as T
    }
  }
}
