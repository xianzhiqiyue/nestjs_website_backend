import { Controller, Post, UseInterceptors, UploadedFiles } from '@nestjs/common'
import { FilesInterceptor } from '@nestjs/platform-express'
import { ApiTags } from '@nestjs/swagger'
import { ApiDataResponse } from 'src/common/decorators/swagger.decorator'
import { BaseVo } from 'src/dto/vo/base.vo'
import { UploadService } from './upload.service'

@ApiTags('图片上传')
@Controller('upload')
export class UploadController {
  constructor(private uploadService: UploadService) {}

  @ApiDataResponse(BaseVo)
  @Post('uploadImg')
  @UseInterceptors(FilesInterceptor('file'))
  uploadFile(@UploadedFiles() files: Express.Multer.File[]) {
    return this.uploadService.upload(files)
  }
}
