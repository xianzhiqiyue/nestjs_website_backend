import { Inject, Injectable, Scope } from '@nestjs/common'
import { REQUEST } from '@nestjs/core'
import { PROVIDERS } from 'src/common/enums/sysyem.enum'
import { encryptFileMD5, getIPAddress } from 'src/common/utils/util'
import { DataSource, EntityManager } from 'typeorm'
import * as fs from 'fs'
import * as path from 'path'
import { PictureEntity } from 'src/entities/picture.entity'
import { CreatePictureDto } from 'src/dto/picture.dto'

const ip = getIPAddress()
const uploadStaticSrc = '/public/'
@Injectable({ scope: Scope.REQUEST })
export class UploadService {
  constructor(
    @Inject(REQUEST) private readonly req: any,
    @Inject(PROVIDERS.DB) private dataSource: DataSource
  ) {}

  getImageSrc(src: string): string {
    return `http://${ip}:${process.env.PORT}/static/${src}`
  }

  create(createPictureDto: CreatePictureDto) {
    return this.dataSource.transaction(async (manager: EntityManager) => {
      const pic = manager.merge(PictureEntity, new PictureEntity(), createPictureDto)
      return manager.save(pic as PictureEntity)
    })
  }

  upload(files: Express.Multer.File[]) {
    const savePromises = files.map((file: Express.Multer.File) => {
      const { buffer } = file
      const sign = encryptFileMD5(buffer)
      const arr = file.originalname.split('.')
      const fileType = arr[arr.length - 1]
      const fileName = sign + '.' + fileType
      const _path = path.join(process.cwd(), `${uploadStaticSrc}/${fileName}`)
      fs.writeFileSync(_path, buffer)

      const src = fileName
      return this.create({
        src,
        sign
      })
    }) as Array<Promise<PictureEntity>>
    return Promise.all(savePromises)
  }
}
