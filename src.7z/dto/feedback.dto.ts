import { PartialType, ApiProperty, PickType, IntersectionType } from '@nestjs/swagger'
import { IsNotEmpty, IsString, IsOptional, IsDateString } from 'class-validator'
import { QUESTION_TYPE } from 'src/common/enums/feedback.enum'
import { FeedbackEntity } from 'src/entities/feedback.entity'
import { BaseIdDto, QueryOptionsDto } from './base.dto'

export class CreateFeedbackDto extends PickType(FeedbackEntity, [
  'product',
  'files',
  'bussinessLine'
] as const) {
  /** 问题类型 */
  @IsNotEmpty()
  @ApiProperty({ enum: QUESTION_TYPE, enumName: '问题类型' })
  type: QUESTION_TYPE

  /** 产品ID */
  @IsNotEmpty()
  @IsString()
  productId: string

  /** 事件ID */
  @IsNotEmpty()
  @IsString()
  eventId: string

  /** 反馈内容 */
  @IsNotEmpty()
  @IsString()
  content: string

  /** 软件版本 */
  @IsNotEmpty()
  @IsString()
  version: string

  /** 联系方式 */
  @IsString()
  @IsOptional()
  contact: string

  /** 联系人名称 */
  @IsString()
  @IsOptional()
  name: string

  /** 额外的一些数据 */
  @IsString()
  @IsOptional()
  extraJson: string
}

export class DeleteFeedbackDto extends BaseIdDto {}

export class GetFeedbackListDto extends IntersectionType(
  QueryOptionsDto,
  PartialType(PickType(FeedbackEntity, ['status', 'content'] as const))
) {
  @IsString()
  @IsOptional()
  readonly productId?: number

  @IsString()
  @IsOptional()
  readonly bussinessLineId: number

  @IsString()
  @IsOptional()
  readonly status: string

  /** 起始日期 */
  @IsDateString()
  @IsOptional()
  readonly startDate: string

  /** 结束日期 */
  @IsDateString()
  @IsOptional()
  readonly endDate: string
}

export class UpdateFeedbackDto extends PartialType(FeedbackEntity) {
  @IsNotEmpty()
  id: number
}

export class UpdateFeedbackStatusDto extends PickType(FeedbackEntity, ['id', 'status'] as const) {}
