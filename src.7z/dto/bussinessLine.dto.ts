import { OmitType, PartialType } from '@nestjs/swagger'
import { IsNotEmpty } from 'class-validator'
import { BussinesslineEntity } from 'src/entities/bussinessLine.entity'
import { QueryOptionsDto } from './base.dto'

export class CreateBussinessLineDto {
  bussinessLineName: string
}

export class GetBussinessLineListDto extends QueryOptionsDto {}

export class UpdateBussinessLineDto extends OmitType(PartialType(BussinesslineEntity), [
  'sentryId'
] as const) {
  @IsNotEmpty()
  id: number
}
