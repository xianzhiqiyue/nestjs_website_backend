import { IsString, IsNotEmpty } from 'class-validator'

export class LoginDto {
  /** 用户名 */
  @IsString({ message: '用户名必须为字符类型' })
  @IsNotEmpty({ message: '用户名不能为空' })
  username: string
  /** 密码 */
  @IsString({ message: '密码必须为字符串类型' })
  @IsNotEmpty({ message: '密码不能为空' })
  password: string
}

export class RegisterDto {
  /** 用户名 */
  @IsString()
  @IsNotEmpty()
  username: string
  /** 密码 */
  @IsString()
  @IsNotEmpty()
  password: string
}
