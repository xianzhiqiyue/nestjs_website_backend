export class BaseVo {
  /** id */
  id: number

  /** 创建 */
  createdAt: Date

  /** 创建者 */
  createId: number

  /** 修改者 */
  updateId: number
}
