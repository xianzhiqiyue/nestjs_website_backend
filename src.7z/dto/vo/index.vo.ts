import * as UserVo from './user.vo'
export default { ...UserVo }
