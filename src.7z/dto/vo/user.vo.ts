export class UserVo {
  /** 用户角色 */
  role: number
  /** 用户名称 */
  username: string
}
export class LoginVo {
  /** token */
  token: string
}
export class AffectedVO {
  /** 影响条数 */
  affected: number
}
