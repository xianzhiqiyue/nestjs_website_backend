import { ApiProperty, PartialType } from '@nestjs/swagger'
import { IsEmail, IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator'
import { Role } from 'src/common/enums/role.enum'
import { UserEntity } from 'src/entities/user.entity'
import { QueryOptionsDto } from './base.dto'
export class UserDto extends UserEntity {}
export class GetUserListDto extends QueryOptionsDto {
  /** 用户名 */
  @IsString()
  @IsOptional()
  username?: string
}

export class CreateUserDto {
  /** 用户名 */
  @IsNotEmpty()
  @IsString()
  username: string

  /** 密码 */
  @IsNotEmpty()
  @IsString()
  password: string

  /** 密码 */
  @IsEmail()
  email: string

  /** 所属业务线 */
  @IsNumber()
  @IsOptional()
  bussinessLineId: number

  @IsNotEmpty()
  @ApiProperty({
    enum: Role
  })
  role: Role
}
export class UpdateUserDto extends PartialType(UserEntity) {
  /** ID */
  @IsNotEmpty()
  id: number

  /** 所属业务线 */
  @IsNotEmpty()
  @IsNumber()
  bussinessLineId: number
}
