import { OmitType, PartialType } from '@nestjs/swagger'
import { IsArray, IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator'
import { ProductEntity } from 'src/entities/product.entity'
import { QueryOptionsDto } from './base.dto'

export class CreateProductDto {
  /** 产品名称 */
  @IsNotEmpty()
  @IsString()
  productName: string

  /** 产品ID */
  @IsNotEmpty()
  @IsString()
  slugName: string

  /** 业务线 */
  @IsNotEmpty()
  @IsNumber()
  bussinessLineId: number

  @IsArray()
  @IsOptional()
  userIds: number[]
}

export class GetProductListDto extends QueryOptionsDto {
  /** 业务线 */
  @IsString()
  @IsOptional()
  bussinessLineId: number
}

export class UpdateProductDto extends OmitType(PartialType(ProductEntity), ['dsnUrl'] as const) {
  @IsNotEmpty()
  @IsNumber()
  id: number

  @IsNotEmpty()
  @IsNumber()
  bussinessLineId: number

  @IsArray()
  @IsOptional()
  userIds: number[]
}

export class GetProductDto {
  @IsNotEmpty()
  id: number
}
