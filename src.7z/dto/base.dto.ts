import { ApiExtraModels, ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'
import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator'
import AllVo from './vo/index.vo'
@ApiExtraModels(...Object.values(AllVo))
export class QueryOptionsDto {
  @ApiPropertyOptional({
    required: false,
    description: '一页显示多少条',
    default: 10
  })
  @IsString()
  @IsOptional()
  readonly pageSize?: number

  @ApiPropertyOptional({
    required: false,
    description: '当前页',
    default: 1
  })
  @IsString()
  @IsOptional()
  readonly pageNum?: number
}

export class BaseIdDto {
  @ApiProperty({ description: 'ID' })
  @IsNotEmpty()
  id: number
}
