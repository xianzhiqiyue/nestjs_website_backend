import { Entity, Column, BaseEntity, PrimaryGeneratedColumn, Index, ManyToOne } from 'typeorm'
import { FeedbackEntity } from './feedback.entity'

@Entity('picture')
export class PictureEntity extends BaseEntity {
  /** 主键id */
  @Index('id', { unique: true })
  @PrimaryGeneratedColumn()
  id: number

  // 图片路径
  @Column('text')
  src: string

  // 文件签名
  @Column('text')
  sign: string

  @ManyToOne(() => FeedbackEntity, (feedback) => feedback.files, { onDelete: 'CASCADE' })
  feedback: FeedbackEntity
}
