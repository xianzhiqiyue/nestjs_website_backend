import { ApiHideProperty } from '@nestjs/swagger'
import { IsString } from 'class-validator'
import { IS_DELETED } from 'src/common/enums/sysyem.enum'
import { SharedEntity } from 'src/common/shared/shared.entity'
import { Column, Entity, JoinTable, ManyToMany, ManyToOne, OneToMany } from 'typeorm'
import { BussinesslineEntity } from './bussinessLine.entity'
import { FeedbackEntity } from './feedback.entity'
import { UserEntity } from './user.entity'

@Entity('product')
export class ProductEntity extends SharedEntity {
  /** 产品名称 */
  @Column({ comment: '产品名称' })
  @IsString()
  productName: string

  /** 产品名称 */
  @Column({ comment: 'Sentry Slug name' })
  @IsString()
  slugName: string

  /** DSN地址 */
  @Column({ comment: 'DSN地址', default: '' })
  @IsString()
  dsnUrl: string

  /** 是否删除 */
  @ApiHideProperty()
  @Column({
    comment: '是否删除',
    default: IS_DELETED.UN_DELETED,
    type: 'enum',
    enum: IS_DELETED,
    select: false
  })
  isDeleted: IS_DELETED

  @OneToMany(() => FeedbackEntity, (f) => f.product)
  feedback: FeedbackEntity[]

  @ManyToOne(() => BussinesslineEntity, (bl) => bl.products)
  bussinessLine: BussinesslineEntity

  @ManyToMany(() => UserEntity, (user) => user.products)
  @JoinTable()
  users: UserEntity[]
}
