import { IsString, IsEnum } from 'class-validator'
import { QUESTION_TYPE, STATUS_TYPE } from 'src/common/enums/feedback.enum'
import { SharedEntity } from 'src/common/shared/shared.entity'
import { Column, Entity, OneToMany, ManyToOne } from 'typeorm'
import { BussinesslineEntity } from './bussinessLine.entity'
import { PictureEntity } from './picture.entity'
import { ProductEntity } from './product.entity'

@Entity('feedback')
export class FeedbackEntity extends SharedEntity {
  /** 问题类型 */
  @Column({ comment: '问题类型', enum: QUESTION_TYPE, type: 'enum', default: QUESTION_TYPE.EXPERIENCE })
  @IsEnum(QUESTION_TYPE)
  type: QUESTION_TYPE

  /** 产品名称 */
  @ManyToOne(() => ProductEntity, (p) => p.feedback)
  product: ProductEntity

  /** 反馈内容 */
  @Column({ comment: '反馈内容' })
  @IsString()
  content: string

  /** 版本号 */
  @Column({ comment: '版本号' })
  @IsString()
  version: string

  /** 联系方式 */
  @Column({ comment: '联系方式', default: '' })
  @IsString()
  contact: string

  /** 联系人 */
  @Column({ comment: '联系人', default: '' })
  @IsString()
  name: string

  /** 事件ID */
  @Column({ comment: '事件ID', default: '' })
  @IsString()
  eventId: string

  /** 可能记录的一些JSON数据 */
  @Column({ comment: '额外的记录', default: '' })
  @IsString()
  extraJson: string

  /** 问题类型 */
  @Column({ comment: '处理状态', enum: STATUS_TYPE, type: 'enum', default: STATUS_TYPE.UNRESOLVED })
  @IsEnum(STATUS_TYPE)
  status: string

  /** 反馈图片 */
  @OneToMany(() => PictureEntity, (picture) => picture.feedback)
  files: PictureEntity[]

  /** 所属业务线 */
  @ManyToOne(() => BussinesslineEntity, (bussinessline) => bussinessline.feedbacks)
  bussinessLine: BussinesslineEntity
}
