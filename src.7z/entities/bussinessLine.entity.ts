import { ApiHideProperty } from '@nestjs/swagger'
import { IsString } from 'class-validator'
import { IS_DELETED } from 'src/common/enums/sysyem.enum'
import { SharedEntity } from 'src/common/shared/shared.entity'
import { Column, Entity, OneToMany } from 'typeorm'
import { FeedbackEntity } from './feedback.entity'
import { ProductEntity } from './product.entity'
import { UserEntity } from './user.entity'

@Entity('bussinessline')
export class BussinesslineEntity extends SharedEntity {
  /** 业务线名称 */
  @Column({ comment: '业务线名称' })
  @IsString()
  bussinessLineName: string

  /** SentryId */
  @Column({ comment: 'Sentry ID', default: '' })
  @IsString()
  sentryId: string

  /** 是否删除 */
  @ApiHideProperty()
  @Column({
    comment: '是否删除',
    default: IS_DELETED.UN_DELETED,
    type: 'enum',
    enum: IS_DELETED,
    select: false
  })
  isDeleted: IS_DELETED

  @OneToMany(() => ProductEntity, (product) => product.bussinessLine)
  products: ProductEntity[]

  @OneToMany(() => FeedbackEntity, (feedback) => feedback.bussinessLine)
  feedbacks: FeedbackEntity[]

  @OneToMany(() => UserEntity, (user) => user.bussinessLine)
  users: UserEntity[]
}
