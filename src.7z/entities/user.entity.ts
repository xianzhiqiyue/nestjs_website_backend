import { ApiHideProperty } from '@nestjs/swagger'
import { IsNotEmpty, IsEnum, IsEmail } from 'class-validator'
import { Role } from 'src/common/enums/role.enum'
import { IS_DELETED } from 'src/common/enums/sysyem.enum'
import { SharedEntity } from 'src/common/shared/shared.entity'
import { Column, Entity, Index, ManyToMany, ManyToOne } from 'typeorm'
import { BussinesslineEntity } from './bussinessLine.entity'
import { ProductEntity } from './product.entity'

@Entity('users')
export class UserEntity extends SharedEntity {
  /** 用户名 */
  @Index('username', { unique: true })
  @Column({ comment: '用户名', length: 50 })
  username: string

  /** 密码 */
  @ApiHideProperty()
  @Column({ comment: '密码', length: 100, select: false })
  password: string

  /** 用户角色 */
  @IsNotEmpty()
  @Column({ comment: '用户角色', type: 'enum', enum: Role, default: Role.NORMAL })
  @IsEnum(Role)
  role: Role

  /** 是否删除 */
  @ApiHideProperty()
  @Column({
    comment: '是否删除',
    default: IS_DELETED.UN_DELETED,
    type: 'enum',
    enum: IS_DELETED,
    select: false
  })
  isDeleted: IS_DELETED

  /** 用户邮箱 */
  @IsEmail()
  @Column({ comment: '邮箱' })
  email: string

  @ManyToOne(() => BussinesslineEntity, (bl) => bl.users)
  bussinessLine: BussinesslineEntity

  @ManyToMany(() => ProductEntity, (pr) => pr.users)
  products: ProductEntity[]
}
