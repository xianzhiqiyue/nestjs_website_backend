import { BussinesslineEntity } from './bussinessLine.entity'
import { FeedbackEntity } from './feedback.entity'
import { PictureEntity } from './picture.entity'
import { ProductEntity } from './product.entity'
import { UserEntity } from './user.entity'

export const AllEntities = [PictureEntity, FeedbackEntity, ProductEntity, UserEntity, BussinesslineEntity]
